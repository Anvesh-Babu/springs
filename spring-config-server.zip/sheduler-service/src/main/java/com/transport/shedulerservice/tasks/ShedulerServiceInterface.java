package com.transport.shedulerservice.tasks;

public interface ShedulerServiceInterface {
	
  public void modifyStatus();
}
