package com.pixogram.commentservices.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Id;

import org.hibernate.annotations.CreationTimestamp;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;



@Entity
@Table(name = "comment")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Comment {

	   @Id
       private Integer Id;
	   @Column
       private Integer mediaId;
	   @Column
       private Integer userId;
	   @Column
       private String comment;
	   @Column @CreationTimestamp
       private LocalDateTime creadtedon;
	
	
}
