package com.pixogram.commentservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class commentservicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(commentservicesApplication.class, args);
	}

}
