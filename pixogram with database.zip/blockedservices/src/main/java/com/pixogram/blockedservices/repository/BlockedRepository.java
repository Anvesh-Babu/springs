package com.pixogram.blockedservices.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.pixogram.blockedservices.entity.Blocked;
@Repository
public interface BlockedRepository extends JpaRepository <Blocked,Integer> {

}
