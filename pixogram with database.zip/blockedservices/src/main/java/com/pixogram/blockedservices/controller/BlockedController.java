package com.pixogram.blockedservices.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.pixogram.blockedservices.entity.Blocked;
import com.pixogram.blockedservices.repository.BlockedRepository;


@RestController
public class BlockedController {

	@Autowired
	private Environment env;
	
	
	@Autowired
	
	private BlockedRepository blockedRepository;
	
	
	@GetMapping("/block/{blockedId}")
	public ResponseEntity<Blocked> followingDetail(@PathVariable Integer blockedId){
		Optional<Blocked> record = this.blockedRepository.findById(blockedId);
		Blocked block = new Blocked();
		if(record.isPresent())
			block = record.get();
		ResponseEntity<Blocked> response = new ResponseEntity<Blocked>(block, HttpStatus.OK);
		return response;
	}
}
