package com.pixogram.userservices.service;

import java.util.List;

import com.pixogram.userservices.entity.Users;

public interface IUserService {

	
	
	List<Users> findAll();
     Users finduserById(Integer id);
	boolean addUsers(Users users);
	boolean updateuserst(Users users);
	boolean deleteUsers(Integer id);
}
