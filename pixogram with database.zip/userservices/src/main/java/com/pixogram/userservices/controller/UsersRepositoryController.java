package com.pixogram.userservices.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.core.env.Environment;
import com.pixogram.userservices.entity.Users;
import com.pixogram.userservices.repository.UserRepository;

@RestController
public class UsersRepositoryController {

	@Autowired
	private Environment env;
	
	@Autowired
	private UserRepository usersRepository;

	@GetMapping("/users/{userId}")
	public ResponseEntity<Users> userDetail(@PathVariable Integer userId){
		Optional<Users> record = this.usersRepository.findById(userId);
		Users user = new Users();
		if(record.isPresent())
			user = record.get();
		ResponseEntity<Users> response = new ResponseEntity<Users>(user, HttpStatus.OK);
		return response;
	}
	
	
}
