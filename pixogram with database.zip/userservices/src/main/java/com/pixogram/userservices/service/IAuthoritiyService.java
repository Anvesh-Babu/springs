package com.pixogram.userservices.service;

import java.util.List;

import com.pixogram.userservices.entity.Authorities;



public interface IAuthoritiyService {

	
	
	List<Authorities> findAll();
    Authorities findAuthoritiesById(Integer id);
	boolean addAuthorities(Authorities authorit);
	boolean updateAuthorities(Authorities authorit);
	boolean deleteAuthorities(Integer id);
}
