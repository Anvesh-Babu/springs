package com.cts.training.MediaPro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MediaProApplicationTests {

	@Test
	void contextLoads() {
	}

}
