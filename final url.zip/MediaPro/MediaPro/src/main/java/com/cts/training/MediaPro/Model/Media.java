package com.cts.training.MediaPro.Model;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString


public class Media {
	
	private Integer id;
	private Integer userId;
	private String title;
	private String description;
	private String mimeType;
	private Integer size;
	private String posterFileUrl;
	private String fileUrl;
	private Boolean hide;
	private LocalDateTime createdOn;
	private LocalDateTime updatedOn;
	private String tags;
}
