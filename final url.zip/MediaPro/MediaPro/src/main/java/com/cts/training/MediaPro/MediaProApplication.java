package com.cts.training.MediaPro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MediaProApplication {

	public static void main(String[] args) {
		SpringApplication.run(MediaProApplication.class, args);
	}

}
