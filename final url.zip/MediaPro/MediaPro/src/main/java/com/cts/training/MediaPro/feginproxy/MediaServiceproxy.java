package com.cts.training.MediaPro.feginproxy;

import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.cts.training.MediaPro.Model.Media;

@FeignClient(name = "api-gateway")
@RibbonClient(name = "media-service")
public interface MediaServiceproxy {

	@GetMapping("media-service/media/{mediaId}")
	public ResponseEntity<Media> movieDetail(@PathVariable Integer mediaId);
}
