package com.cts.training.followservice.service;

import java.util.List;

import com.cts.training.followservice.entity.Follow;



public interface IFollowService {

	List<Follow> findAllFollows();
	Follow findFollowById(Integer id);
	boolean addFollow(Follow Follow);
	boolean updateFollow(Follow Follow);
	boolean deleteFollow(Integer id);
}
