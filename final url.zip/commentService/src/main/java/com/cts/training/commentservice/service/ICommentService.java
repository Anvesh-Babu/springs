package com.cts.training.commentservice.service;

import java.util.List;

import com.cts.training.commentservice.entity.Comment;





public interface ICommentService {

	List<Comment> findAllComments();
	Comment findCommentById(Integer id);
	boolean addComment(Comment Comment);
	boolean updateComment(Comment Comment);
	boolean deleteComment(Integer id);
}
