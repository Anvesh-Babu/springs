package com.cts.training.Newsfeedservice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.cts.training.Newsfeedservice.entity.Newsfeed;
import com.cts.training.Newsfeedservice.repository.NewsfeedRepository;






// @Component
@Service
public class NewsfeedServiceImpl implements INewsfeedService {

	@Autowired
	private NewsfeedRepository newsfeedRepository;
	
	
	
	// get all
	@Override
	public List<Newsfeed> findAllNewsfeeds() {
		// add additional logic
		return this.newsfeedRepository.findAll();
	}

	
	
	/// by id
	@Override
	public Newsfeed findNewsfeedById(Integer id) {
		// TODO Auto-generated method stub
		// resolves problem of null reference exception
		Optional<Newsfeed> record =  this.newsfeedRepository.findById(id);
		// reduces the chance of NullException
		
		// can check if object is there
		Newsfeed newsfeed = new Newsfeed();
		if(record.isPresent())
			newsfeed = record.get();
		return newsfeed;
		
	}
	
	
	
	@Override
	public boolean addNewsfeed(Newsfeed newsfeed) {
		// TODO Auto-generated method stub
		this.newsfeedRepository.save(newsfeed);
		return true;
	}
	
	
	@Override
	public boolean updateNewsfeed(Newsfeed newsfeed) {
		// TODO Auto-generated method stub
		this.newsfeedRepository.save(newsfeed);
		return true;
	}

	@Override
	public boolean deleteNewsfeed(Integer id) {
		// TODO Auto-generated method stub
		this.newsfeedRepository.deleteById(id);
		return true;
	}
	
	


	
	
}
