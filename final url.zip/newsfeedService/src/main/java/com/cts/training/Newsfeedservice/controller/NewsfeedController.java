package com.cts.training.Newsfeedservice.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.training.Newsfeedservice.entity.Newsfeed;
import com.cts.training.Newsfeedservice.repository.NewsfeedRepository;
import com.cts.training.Newsfeedservice.service.INewsfeedService;

@RestController
public class NewsfeedController {

	// dependency
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private INewsfeedService newsfeedService;

	
	
	
	
	@GetMapping("/newsfeed") // GET HTTP VERB
	public ResponseEntity<List<Newsfeed>> exposeAll() {
		
		List<Newsfeed> newsfeed = this.newsfeedService.findAllNewsfeeds();
		ResponseEntity<List<Newsfeed>> response = 
								new ResponseEntity<List<Newsfeed>>(newsfeed, HttpStatus.OK);
		
		
		return response;
	}	
	
	// REST method that will recieve a movie Id and return details of that movie
	@GetMapping("/newsfeed/{newsfeedId}") // GET HTTP VERB
	public ResponseEntity<Newsfeed> getById(@PathVariable Integer newsfeedId) {
		
		Newsfeed newsfeed = this.newsfeedService.findNewsfeedById(newsfeedId);
		ResponseEntity<Newsfeed> response = 
				new ResponseEntity<Newsfeed>(newsfeed, HttpStatus.OK);

		return response;
	}
	
	
	
	@PostMapping("/newsfeed") // POST HTTP VERB
	public ResponseEntity<Newsfeed> save(@RequestBody Newsfeed newsfeed) {
		this.newsfeedService.addNewsfeed(newsfeed);
		ResponseEntity<Newsfeed> response = 
				new ResponseEntity<Newsfeed>(newsfeed, HttpStatus.OK);

		return response;
	}
	
	
	
	@PutMapping("/newsfeed/{newsfeedId}")
	
		public ResponseEntity<Newsfeed> saveUpdate(@PathVariable Integer newsfeedId,@RequestBody Newsfeed newsfeed) {
		
		Newsfeed n = new Newsfeed (newsfeed.getId(),newsfeed.getMediaId(),newsfeed.getFeed(),newsfeed.getCreatedOn(),newsfeed.getUserId());

		if(!this.newsfeedService.updateNewsfeed(n))
			throw new RuntimeException("could not update");
			
		ResponseEntity<Newsfeed> response = 
				new ResponseEntity<Newsfeed>(n, HttpStatus.OK);

		return response;
	}
	
	
	
	
	
	@DeleteMapping("/newsfeed/{newsfeedId}")
	public ResponseEntity<Newsfeed> delete(@PathVariable Integer newsfeedId) {
		
		Newsfeed newsfeed = this.newsfeedService.findNewsfeedById(newsfeedId);
		this.newsfeedService.deleteNewsfeed(newsfeedId);
		
		ResponseEntity<Newsfeed> response = 
				new ResponseEntity<Newsfeed>(newsfeed, HttpStatus.OK);

		return response;
	}
	
}
	
	







