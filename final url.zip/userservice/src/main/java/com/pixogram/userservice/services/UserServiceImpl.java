package com.pixogram.userservice.services;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pixogram.userservice.entity.Authorities;
import com.pixogram.userservice.entity.User;
import com.pixogram.userservice.model.UserRegistrationModel;
import com.pixogram.userservice.repository.AuthorityRepository;
import com.pixogram.userservice.repository.UserRepository;
@Service
public class UserServiceImpl implements IUserService {
	
	@Autowired
	private UserRepository userRepository;
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private AuthorityRepository authorityRepository;
	
	
	@Override
	public List<User> findAllUsers() {
		// TODO Auto-generated method stub
		return this.userRepository.findAll();
	}

	@Override
	public Optional<User> findUserById(Integer id) {
		// TODO Auto-generated method stub
		Optional<User> user = this.userRepository.findById(id);
		return user;
	}

	@Override

	public void saveuser(UserRegistrationModel user) {
		User data = new User();
		data.setUserName(user.getUsername());
		logger.info(user.getUsername());
		data.setFirstName(user.getFname());
		data.setLastName(user.getLname());
		data.setPassword("{noop}" + user.getPassword());
		data.setEmail(user.getUemail());
		data.setProfilePic(user.getProfile());
		data.setEnabled(true);
		this.userRepository.save(data);
		
		// add authority
		Authorities role = new Authorities(user.getUsername(), "ROLE_USER");
		this.authorityRepository.save(role);
	}
	
	@Override
	public boolean updateUser(User user) {
		// TODO Auto-generated method stub
		this.userRepository.save(user);
		return false;
	
	}

	@Override
	public boolean deleteUser(Integer id) {
		// TODO Auto-generated method stub
		this.userRepository.deleteById(id);
		return false;
	}
	
}
