package com.pixogram.userservice.services;

import java.util.List;
import java.util.Optional;

import com.pixogram.userservice.entity.User;
import com.pixogram.userservice.model.UserRegistrationModel;

public interface IUserService {
	List<User> findAllUsers();
	Optional<User> findUserById(Integer id);
	public void saveuser(UserRegistrationModel userInput);
	boolean updateUser(User user);
	boolean deleteUser(Integer id);
}
