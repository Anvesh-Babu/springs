package com.pixogram.followingservices.service;

import java.util.List;

import com.pixogram.followingservices.entity.Following;





public interface IFollowService {

	List<Following> findAllFollows();
	Following findFollowById(Integer id);
	boolean addFollow(Following Follow);
	boolean updateFollow(Following Follow);
	boolean deleteFollow(Integer id);
}
