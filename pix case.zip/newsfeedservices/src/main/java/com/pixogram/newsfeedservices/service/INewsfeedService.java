package com.pixogram.newsfeedservices.service;

import java.util.List;

import com.pixogram.newsfeedservices.entity.Newsfeed;

public interface INewsfeedService {

	List<Newsfeed> findAllNewsfeeds();
	Newsfeed findNewsfeedById(Integer id);
	boolean addNewsfeed(Newsfeed Newsfeed);
	boolean updateNewsfeed(Newsfeed Newsfeed);
	boolean deleteNewsfeed(Integer id);
}
