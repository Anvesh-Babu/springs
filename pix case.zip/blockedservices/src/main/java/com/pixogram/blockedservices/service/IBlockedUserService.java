package com.pixogram.blockedservices.service;

import java.util.List;

import com.pixogram.blockedservices.controller.BlockedController;
import com.pixogram.blockedservices.entity.Blocked;




public interface IBlockedUserService {

	List<Blocked> findAllBlockedUser();
	Blocked findBlockedUserById(Integer id);
	boolean addBlockedUser(Blocked BlockedUser);
	boolean updateBlockedUser(Blocked BlockedUser);
	boolean deleteBlockedUser(Integer id);
}
