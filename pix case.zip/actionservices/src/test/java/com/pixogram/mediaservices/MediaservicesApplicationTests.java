package com.pixogram.mediaservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MediaservicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
