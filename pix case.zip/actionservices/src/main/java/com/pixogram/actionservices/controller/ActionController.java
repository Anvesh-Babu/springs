package com.pixogram.actionservices.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.pixogram.actionservices.entity.Action;
import com.pixogram.actionservices.repository.ActionRepository;

@RestController
public class ActionController {

	
	
	@Autowired
	private ActionRepository actionRepository;
	
	
	@GetMapping("/action/{actionId}")
	public ResponseEntity<Action> actionDetail(@PathVariable Integer actionId){
		Optional<Action> record = this.actionRepository.findById(actionId);
		Action action = new Action();
		if(record.isPresent())
			action = record.get();
		ResponseEntity<Action> response = new ResponseEntity<Action>(action, HttpStatus.OK);
		return response;
	}
	
	
}
