package com.pixogram.actionservices.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "action")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Action {

	@Id
	private Integer id;
	@Column
	private Integer mediaid;
	@Column
	private Integer userid;
	@Column
	private boolean status;
	@Column
	private LocalDateTime createdon;
}
