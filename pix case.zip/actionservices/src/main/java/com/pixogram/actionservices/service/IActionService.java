package com.pixogram.actionservices.service;

import java.util.List;

import com.pixogram.actionservices.entity.Action;



public interface IActionService {

	List<Action> findAllActions();
	Action findActionById(Integer id);
	boolean addAction(Action Action);
	boolean updateAction(Action Action);
	boolean deleteAction(Integer id);
}
