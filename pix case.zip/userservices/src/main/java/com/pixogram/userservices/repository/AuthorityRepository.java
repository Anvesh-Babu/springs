package com.pixogram.userservices.repository;

import com.pixogram.userservices.entity.Authorities;

public interface AuthorityRepository{
	
	public void save(Authorities auth);

	

}
