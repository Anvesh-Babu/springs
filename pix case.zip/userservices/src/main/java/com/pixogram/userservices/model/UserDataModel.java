package com.pixogram.userservices.model;

import java.util.List;

import com.pixogram.userservices.entity.Users;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class UserDataModel {

	
	public List<Users> users; 
	
}
