package com.pixogram.mediaservices.service;

import java.util.List;

import com.pixogram.mediaservices.entity.Media;








public interface IMediaService {

	List<Media> findAllMedias();
	Media findMediaById(Integer id);
	boolean addMedia(Media Media);
	boolean updateMedia(Media Media);
	boolean deleteMedia(Integer id);
}
