package com.pixogram.commentservices.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.pixogram.commentservices.entity.Comment;
import com.pixogram.commentservices.repository.CommentRepository;







// @Component
@Service
public class CommentServiceImpl implements ICommentService {

	@Autowired
	private CommentRepository commentRepository;
	
	
	
	// get all
	@Override
	public List<Comment> findAllComments() {
		// add additional logic
		return this.commentRepository.findAll();
	}

	
	
	/// by id
	@Override
	public Comment findCommentById(Integer id) {
		// TODO Auto-generated method stub
		// resolves problem of null reference exception
		Optional<Comment> record =  this.commentRepository.findById(id);
		// reduces the chance of NullException
		
		// can check if object is there
		Comment comment = new Comment();
		if(record.isPresent())
			comment = record.get();
		return comment;
		
	}
	
	
	
	@Override
	public boolean addComment(Comment comment) {
		// TODO Auto-generated method stub
		this.commentRepository.save(comment);
		return true;
	}
	
	
	@Override
	public boolean updateComment(Comment comment) {
		// TODO Auto-generated method stub
		this.commentRepository.save(comment);
		return true;
	}

	@Override
	public boolean deleteComment(Integer id) {
		// TODO Auto-generated method stub
		this.commentRepository.deleteById(id);
		return true;
	}
	
	


	
	
}
