package com.pixogram.mediaservices.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import com.pixogram.mediaservices.repository.MediaRepository;

@RestController
public class MediaController {

	
	@Autowired
	private MediaRepository mediaRepository;
}
