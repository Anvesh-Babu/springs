package com.pixogram.mediaservices.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "media")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString

public class Media {

	
	@Id
	private Integer id;
	@Column
	private Integer userid;
	@Column(name="media")
	private String title;
	@Column
	private String Description;
	@Column
	private String mimetype;
	@Column
	private String posterfileurl;
	@Column
	private String fileurl;
	@Column
	private String hide;
	@Column @CreationTimestamp
	private LocalDateTime createdon;
	@Column @UpdateTimestamp
	private LocalDateTime updatedon;
	@Column
	private boolean enabled;
	
}
