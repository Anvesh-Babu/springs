package com.pixogram.actionservices.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.pixogram.actionservices.entity.Action;

@Repository
public interface ActionRepository extends JpaRepository <Action, Integer> {

}
