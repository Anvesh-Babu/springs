package com.pixogram.actionservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ActionservicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ActionservicesApplication.class, args);
	}

}
