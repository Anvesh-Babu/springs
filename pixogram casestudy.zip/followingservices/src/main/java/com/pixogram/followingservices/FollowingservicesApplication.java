package com.pixogram.followingservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FollowingservicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(FollowingservicesApplication.class, args);
	}

}
