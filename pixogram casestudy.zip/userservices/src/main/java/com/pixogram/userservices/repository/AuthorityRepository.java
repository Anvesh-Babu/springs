package com.pixogram.userservices.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pixogram.userservices.entity.Authorities;

public interface AuthorityRepository extends JpaRepository<Authorities, Integer> {

}
