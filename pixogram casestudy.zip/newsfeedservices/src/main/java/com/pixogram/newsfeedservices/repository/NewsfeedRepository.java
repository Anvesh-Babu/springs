package com.pixogram.newsfeedservices.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pixogram.newsfeedservices.entity.Newsfeed;

public interface NewsfeedRepository extends JpaRepository<Newsfeed, Integer > {

}
