package com.pixogram.newsfeedservices.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import com.pixogram.newsfeedservices.repository.NewsfeedRepository;

@RestController
public class NewsfeedController {

	
	
	@Autowired
	private NewsfeedRepository newsfeedRepository;
}
