package com.pixogram.commentservices.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import com.pixogram.commentservices.repository.CommentRepository;

@RestController
public class CommentController {

	
	@Autowired
	private CommentRepository commentRepository;
}
