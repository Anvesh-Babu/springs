package com.pixogram.followingservices.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.pixogram.followingservices.entity.Following;
import com.pixogram.followingservices.repository.FollowingRepository;







// @Component
@Service
public abstract class FollowingServiceImpl implements IFollowService {

	@Autowired
	private FollowingRepository followingRepository;
	
	
	
	// get all
	@Override
	public List<Following> findAllFollows() {
		// add additional logic
		return this.followingRepository.findAll();
	}

	
	
	/// by id
	@Override
	public Following findFollowById(Integer id) {
		// TODO Auto-generated method stub
		// resolves problem of null reference exception
		Optional<Following> record =  this.followingRepository.findById(id);
		// reduces the chance of NullException
		
		// can check if object is there
		Following follow = new Following();
		if(record.isPresent())
			follow = record.get();
		return follow;
		
	}
	
	
	
	@Override
	public boolean addFollow(Following follow) {
		// TODO Auto-generated method stub
		this.followingRepository.save(follow);
		return true;
	}
	
	
	@Override
	public boolean updateFollow(Following follow) {
		// TODO Auto-generated method stub
		this.followingRepository.save(follow);
		return true;
	}

	@Override
	public boolean deleteFollow(Integer id) {
		// TODO Auto-generated method stub
		this.followingRepository.deleteById(id);
		return true;
	}
	
	


	
	
}
