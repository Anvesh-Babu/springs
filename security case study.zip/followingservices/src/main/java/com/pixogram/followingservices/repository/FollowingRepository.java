package com.pixogram.followingservices.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.pixogram.followingservices.entity.Following;
@Repository
public interface FollowingRepository extends JpaRepository<Following , Integer> {

}
