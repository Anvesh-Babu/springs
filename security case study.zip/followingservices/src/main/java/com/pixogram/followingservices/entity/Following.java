package com.pixogram.followingservices.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "following")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString

public class Following {

	
	
	@Id
	private Integer userid;
	@Column
	private Integer followerid;
}
