package com.pixogram.followingservices.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.pixogram.followingservices.entity.Following;
import com.pixogram.followingservices.repository.FollowingRepository;



@RestController
public class FollowingRepositoryController {

	@Autowired
	private Environment env;
	
	@Autowired
	private FollowingRepository followingRepository;
	
	
	@GetMapping("/follows/{followingId}")
	public ResponseEntity<Following> followingDetail(@PathVariable Integer followerId){
		Optional<Following> record = this.followingRepository.findById(followerId);
		Following following = new Following();
		if(record.isPresent())
			following = record.get();
		ResponseEntity<Following> response = new ResponseEntity<Following>(following, HttpStatus.OK);
		return response;
	}
	
	
}
