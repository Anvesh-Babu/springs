import { Injectable } from '@angular/core';
import{ HttpClient} from '@angular/common/http';
import { UserRegistrationDetails} from 'src/app/model/User-registration';

const API_URL="http://localhost:3000/userdetails";

@Injectable({
  providedIn: 'root'
})
export class UserRegistrationService {
  getOneuser(id:number){
    // GET http verb
    return this.http.get(API_URL + "/" + id);

  }

  constructor( public http:HttpClient) { 
  }
  addNewUser(details:UserRegistrationDetails){
    return this.http.post(API_URL,details);
  }
   updateuser(details:UserRegistrationDetails, id:number){
    return this.http.put(API_URL+"/"+id,details);
  }
  
}
