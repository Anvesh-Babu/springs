package com.pixogram.mediaservices.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.pixogram.mediaservices.entity.Media;
import com.pixogram.mediaservices.repository.MediaRepository;







// @Component
@Service
public class MediaServiceImpl implements IMediaService {

	@Autowired
	private MediaRepository  mediaRepository;
	
	
	
	// get all
	@Override
	public List<Media> findAllMedias() {
		// add additional logic
		return this.mediaRepository.findAll();
	}

	
	
	/// by id
	@Override
	public Media findMediaById(Integer id) {
		// TODO Auto-generated method stub
		// resolves problem of null reference exception
		Optional<Media> record =  this.mediaRepository.findById(id);
		// reduces the chance of NullException
		
		// can check if object is there
		Media media = new Media();
		if(record.isPresent())
			media = record.get();
		return media;
		
	}
	
	
	
	@Override
	public boolean addMedia(Media media) {
		// TODO Auto-generated method stub
		this.mediaRepository.save(media);
		return true;
	}
	
	
	@Override
	public boolean updateMedia(Media Media) {
		// TODO Auto-generated method stub
		this.mediaRepository.save(Media);
		return true;
	}

	@Override
	public boolean deleteMedia(Integer id) {
		// TODO Auto-generated method stub
		this.mediaRepository.deleteById(id);
		return true;
	}
	
	


	
	
}
