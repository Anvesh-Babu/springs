package com.pixogram.mediaservices.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.pixogram.mediaservices.entity.Media;
import com.pixogram.mediaservices.repository.MediaRepository;

@RestController
public class MediaController {

	
	@Autowired
	private Environment env;
	
	@Autowired
	private MediaRepository mediaRepository;
	
	
	@GetMapping("/medias/{mediaId}")
	public ResponseEntity<Media> mediaDetail(@PathVariable Integer mediaId){
		Optional<Media> record = this.mediaRepository.findById(mediaId);
		Media media = new Media();
		if(record.isPresent())
			media = record.get();
		ResponseEntity<Media> response = new ResponseEntity<Media>(media, HttpStatus.OK);
		return response;
	}
}
