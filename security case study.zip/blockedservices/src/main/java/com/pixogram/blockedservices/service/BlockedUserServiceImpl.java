package com.pixogram.blockedservices.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.pixogram.blockedservices.entity.Blocked;
import com.pixogram.blockedservices.repository.BlockedRepository;







// @Component
@Service
public class BlockedUserServiceImpl implements IBlockedUserService {

	@Autowired
	private BlockedRepository blockedRepository;
	
	
	
	// get all
	@Override
	public List<Blocked> findAllBlockedUser() {
		// add additional logic
		return this.blockedRepository.findAll();
	}

	
	
	/// by id
	@Override
	public Blocked findBlockedUserById(Integer id) {
		// TODO Auto-generated method stub
		// resolves problem of null reference exception
		Optional<Blocked> record =  this.blockedRepository.findById(id);
		// reduces the chance of NullException
		
		// can check if object is there
		Blocked blockedUser = new Blocked();
		if(record.isPresent())
			blockedUser = record.get();
		return blockedUser;
		
	}
	
	
	
	@Override
	public boolean addBlockedUser(Blocked blockedUser) {
		// TODO Auto-generated method stub
		this.blockedRepository.save(blockedUser);
		return true;
	}
	
	
	@Override
	public boolean updateBlockedUser(Blocked blocked) {
		// TODO Auto-generated method stub
		this.blockedRepository.save(blocked);
		return true;
	}

	@Override
	public boolean deleteBlockedUser(Integer id) {
		// TODO Auto-generated method stub
		this.blockedRepository.deleteById(id);
		return true;
	}
	
	


	
	
}
