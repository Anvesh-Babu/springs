package com.pixogram.newsfeedservices.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.pixogram.newsfeedservices.entity.Newsfeed;
import com.pixogram.newsfeedservices.repository.NewsfeedRepository;

@RestController
public class NewsfeedController {

	
	
	@Autowired
	private NewsfeedRepository newsfeedRepository;
	
	
	@GetMapping("/newsfeed/{newsfeedId}")
	public ResponseEntity<Newsfeed> userDetail(@PathVariable Integer newsfeedId){
		Optional<Newsfeed> record = this.newsfeedRepository.findById(newsfeedId);
		Newsfeed newsfeed = new Newsfeed();
		if(record.isPresent())
			newsfeed = record.get();
		ResponseEntity<Newsfeed> response = new ResponseEntity<Newsfeed>(newsfeed, HttpStatus.OK);
		return response;
	}
}
