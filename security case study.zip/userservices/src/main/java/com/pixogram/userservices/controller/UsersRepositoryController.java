package com.pixogram.userservices.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.core.env.Environment;
import com.pixogram.userservices.entity.Users;
import com.pixogram.userservices.exception.UserNotFoundException;
import com.pixogram.userservices.service.IUserService;

@RestController
public class UsersRepositoryController {

		
	

	@Autowired
	private IUserService userServices;
	

	

	@GetMapping("/users/{userId}")
	public ResponseEntity<Users> userDetail(@PathVariable Integer userId){
		Users user = this.userServices.findUserById(userId);
		
		ResponseEntity<Users> response = new ResponseEntity<Users>(user, HttpStatus.OK);
		return response;
	}
	

	@PostMapping("/users") // POST HTTP VERB
	public ResponseEntity<Users> save(@RequestBody  Users users) {
		if(!this.userServices.addUser(users))
			throw new RuntimeException("Could not add new record!!!");
		ResponseEntity<Users> response = 
				new ResponseEntity<Users>(users, HttpStatus.OK);

		return response;
	}
	
	@PutMapping("/users")
	public ResponseEntity<Users> saveUpdate(@RequestBody Users users) {
		if(!this.userServices.updateUser(users))
			throw new RuntimeException("Could not update record!!!");
		ResponseEntity<Users> response = 
				new ResponseEntity<Users>(users, HttpStatus.OK);

		return response;
	}
	
	@DeleteMapping("/users/{userId}")
	public ResponseEntity<Users> delete(@PathVariable Integer userId) {
		
		Users user = this.userServices.findUserById(userId);
		if(user == null)
			throw new UserNotFoundException("Users with id-" + userId + " not Found");
		
		// send productId to DAO via SERVICE
		this.userServices.deleteUser(userId);
		
		ResponseEntity<Users> response = 
				new ResponseEntity<Users>(user, HttpStatus.OK);

		return response;
	}
}
