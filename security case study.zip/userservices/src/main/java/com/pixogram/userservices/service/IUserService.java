package com.pixogram.userservices.service;

import java.util.List;

import com.pixogram.userservices.entity.Users;

public interface IUserService {

	List<Users> findAllUsers();
	Users findUserById(Integer id);
	boolean addUser(Users Users);
	boolean updateUser(Users Users);
	boolean deleteUser(Integer id);
}
