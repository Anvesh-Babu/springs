package com.pixogram.userservices.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "users")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString


public class Users {

	   @Id
       private Integer id;
	   @Column(name="username")
       private String username;
	   @Column
       private String password;
	   @Column
       private String email;
	   @Column
       private String firstname;
	   @Column
       private String lastname;
	   @Column
       private Integer dob;
	   @Column
       private String profilepic;
	   @Column @CreationTimestamp
       private LocalDateTime createdon;
	   @Column @UpdateTimestamp
       private LocalDateTime updatedon;
	   @Column
       private boolean enabled;
	
	
	
}
