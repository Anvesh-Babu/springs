package com.pixogram.userservices.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.pixogram.userservices.entity.Users;
import com.pixogram.userservices.repository.UsersRepository;







// @Component
@Service
public class UserServiceImpl implements IUserService {

	@Autowired
	private UsersRepository userRepository;
	
	
	
	// get all
	@Override
	public List<Users> findAllUsers() {
		// add additional logic
		return this.userRepository.findAll();
	}

	
	
	/// by id
	@Override
	public Users findUserById(Integer id) {
		// TODO Auto-generated method stub
		// resolves problem of null reference exception
		Optional<Users> record =  this.userRepository.findById(id);
		// reduces the chance of NullException
		
		// can check if object is there
		Users users = new Users();
		if(record.isPresent())
			users = record.get();
		return users;
		
	}
	
	
	
	@Override
	public boolean addUser(Users users) {
		// TODO Auto-generated method stub
		this.userRepository.save(users);
		return true;
	}
	
	
	@Override
	public boolean updateUser(Users users) {
		// TODO Auto-generated method stub
		this.userRepository.save(users);
		return true;
	}

	@Override
	public boolean deleteUser(Integer id) {
		// TODO Auto-generated method stub
		this.userRepository.deleteById(id);
		return true;
	}
	
	


	
	
}
