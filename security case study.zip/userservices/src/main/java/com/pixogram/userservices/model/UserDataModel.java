package com.pixogram.userservices.model;



public class UserDataModel {

	
	
	
}
