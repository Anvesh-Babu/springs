package Com.Cts.Training.Transport.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import Com.Cts.Training.Transport.Entity.Employee;
import Com.Cts.Training.Transport.Services.ITransportService;

@RestController
public class EmployeeController {
	
	@Autowired
	private ITransportService iTransportService ;
	

	@GetMapping("/Employee") // GET HTTP VERB
	public ResponseEntity<List<Employee>> exposeAll() {
		
		List<Employee> employee = this.iTransportService.findAllemployee();
		ResponseEntity<List<Employee>> response = 
								new ResponseEntity<List<Employee>>(employee, HttpStatus.OK);
		
		
		return response;
	}	
	
	// REST method that will recieve a movie Id and return details of that movie
	@GetMapping("/employee/{employeeId}") // GET HTTP VERB
	public ResponseEntity<Employee> getById(@PathVariable Integer employeeId) {
		
		Employee employee = this.iTransportService.findEmployeeById(employeeId);
		ResponseEntity<Employee> response = 
				new ResponseEntity<Employee>(employee, HttpStatus.OK);

		return response;
	}
	
	
	
	@PostMapping("/employee") // POST HTTP VERB
	public ResponseEntity<Employee> save(@RequestBody Employee employee) {
		this.iTransportService.addEmployee(employee);
		ResponseEntity<Employee> response = 
				new ResponseEntity<Employee>(employee, HttpStatus.OK);

		return response;
	}
	
	
	/*
	@PutMapping("/employee/{employeeId}")
	
		public ResponseEntity<Employee> saveUpdate(@PathVariable Integer employeeId,@RequestBody Employee employee) {
		
		Employee emp = new Employee (employeeId);

		if(!this.iTransportService.updateBlockedUser(emp))
			throw new RuntimeException("could not update");
			
		ResponseEntity<Employee> response = 
				new ResponseEntity<Employee>(employee, HttpStatus.OK);

		return response;
	}
	*/
	
	
	
	
	@DeleteMapping("/employee/{employeeId}")
	public ResponseEntity<Employee> delete(@PathVariable Integer employeeId) {
		
		Employee emp = this.iTransportService.findEmployeeById(employeeId);
		this.iTransportService.deleteEmployee(employeeId);
		
		ResponseEntity<Employee> response = 
				new ResponseEntity<Employee>(emp, HttpStatus.OK);

		return response;
	}
	
	
	
}


