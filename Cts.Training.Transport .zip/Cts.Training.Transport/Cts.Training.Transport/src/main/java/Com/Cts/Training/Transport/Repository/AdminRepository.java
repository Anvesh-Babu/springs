package Com.Cts.Training.Transport.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import Com.Cts.Training.Transport.Entity.Admin;


public interface AdminRepository extends JpaRepository<Admin, Integer> {

}
