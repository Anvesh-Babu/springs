package Com.Cts.Training.Transport.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import Com.Cts.Training.Transport.Entity.Employee;


public interface EmployeeRepository extends JpaRepository<Employee, Integer> {

}
