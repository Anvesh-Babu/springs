package Com.Cts.Training.Transport.Services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Com.Cts.Training.Transport.Entity.Employee;
import Com.Cts.Training.Transport.Repository.EmployeeRepository;


@Service
public abstract class TransportServiceImpl implements ITransportService {

	
	
	@Autowired
	private EmployeeRepository employeeRepository;
	
	
	
	// get all
	public List<Employee> findAllEmployees() {
		// add additional logic
		return this.employeeRepository.findAll();
	}

	
	
	/// by id
	@Override
	public Employee findEmployeeById(Integer id) {
		 
		return findEmployeeById(id) ;
		
	}
	
	
	
	public boolean addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		this.employeeRepository.save(employee);
		return true;
	}
	
	
	


	@Override
	public List<Employee> findAllemployee() {
		// TODO Auto-generated method stub
		return null;
	}



	


	public void deleteEmployee(Integer employeeId) {
		// TODO Auto-generated method stub
		
	}



	


	
	
}

	
	
	
	
	
	
	
	
	
	
	
	
	
	

