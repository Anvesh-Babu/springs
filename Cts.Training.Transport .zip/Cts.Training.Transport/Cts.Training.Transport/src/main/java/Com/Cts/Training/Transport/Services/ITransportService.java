package Com.Cts.Training.Transport.Services;

import java.util.List;

import Com.Cts.Training.Transport.Entity.Employee;

public interface ITransportService {

	List<Employee> findAllemployee();

	Employee findEmployeeById(Integer employeeId);

	void deleteEmployee(Integer employeeId);

	boolean addEmployee(Employee employee);


}
